import { Suspense } from 'react';

export const Spin = () => (
  <div className="min-h-screen flex items-center justify-center bg-background">
    <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
  </div>
);

export const S = ({ children }: { children: React.ReactNode }) => (
  <Suspense fallback={<Spin />}>{children}</Suspense>
);
